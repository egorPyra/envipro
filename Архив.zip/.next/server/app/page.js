(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 6688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2838)), "/Users/egor/Desktop/WEB/envipro/envipro/app/page.tsx"],
          
        }]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1921)), "/Users/egor/Desktop/WEB/envipro/envipro/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        
      }
      ]
      }.children;
const pages = ["/Users/egor/Desktop/WEB/envipro/envipro/app/page.tsx"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 5285:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67))

/***/ }),

/***/ 1535:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23))

/***/ }),

/***/ 67:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./app/page.module.css
var page_module = __webpack_require__(1184);
var page_module_default = /*#__PURE__*/__webpack_require__.n(page_module);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./app/components/BurgerMenu/burger-menu.module.css
var burger_menu_module = __webpack_require__(2897);
var burger_menu_module_default = /*#__PURE__*/__webpack_require__.n(burger_menu_module);
;// CONCATENATED MODULE: ./app/components/BurgerMenu/BurgerBtn.tsx


function BurgerBtn({ activateMenuFunc }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        onClick: (event)=>{
            event.stopPropagation();
            activateMenuFunc(true);
        },
        className: (burger_menu_module_default()).btn,
        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
            className: (burger_menu_module_default()).line
        })
    });
}

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/components/BurgerMenu/BurgerContent.tsx



function BurgerContent({ isActive, activateMenuFunc }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: isActive ? (burger_menu_module_default()).blur : (burger_menu_module_default()).none
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: isActive ? `${(burger_menu_module_default()).menuContent} ${(burger_menu_module_default()).menuActive}` : `${(burger_menu_module_default()).menuContent}`,
                onClick: (event)=>event.stopPropagation(),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (burger_menu_module_default()).closeBtnWrap,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: ()=>activateMenuFunc(false),
                            className: (burger_menu_module_default()).closeBtn
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: (burger_menu_module_default()).menuList,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: (burger_menu_module_default()).menuListTitle,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/about_us",
                                        children: "О нас"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: (burger_menu_module_default()).menuListSubTitle,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "НАША ИСТОРИЯ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "НАША КОМАНДА"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "КЛИЕНТЫ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "СОХРАНЯЯ УЛУЧШАТЬ"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: (burger_menu_module_default()).menuListTitle,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/services",
                                        children: "Услуги"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: (burger_menu_module_default()).menuListSubTitle,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "ПРОИЗВОДСТВЕННЫЙ ЭКОЛОГИЧЕСКИЙ КОНТРОЛЬ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "ЭКОЛОГИЧЕСКИЙ МОНИТОРИНГ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "РАЗРАБОТКА РАЗРЕШИТЕЛЬНОЙ ПРИРОДООХРАННОЙ ДОКУМЕНТАЦИИ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "ИНЖЕНЕРНЫЕ ИЗЫСКАНИЯ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "НЕДРОПОЛЬЗОВАНИЕ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "ПРОЕКТИРОВАНИЕ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "ЭКОЛОГИЧЕСКОЕ СОПРОВОЖДЕНИЕ ДЕЯТЕЛЬНОСТИ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "ЛАБОРАТОРНЫЕ АНАЛИЗЫ"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "ГЕОДЕЗИЯ, КАРТОГРАФИЯ, ГИС"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "РАЗРЕШЕНИЯ НА ДОБЫВАНИЕ ОБЪЕКТОВ ИЗ КРАСНОЙ КНИГИ И КОМПЕНСАЦИОННЫЕ МЕРОПРИЯТИЯ"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: (burger_menu_module_default()).menuListTitle,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/contacts",
                                    children: "Контакты"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./app/components/LogoPreloader/logoPreloader.module.css
var logoPreloader_module = __webpack_require__(5965);
var logoPreloader_module_default = /*#__PURE__*/__webpack_require__.n(logoPreloader_module);
;// CONCATENATED MODULE: ./app/components/LogoPreloader/LogoPreloader.tsx



function LogoPreloader() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (logoPreloader_module_default()).preloader,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (logoPreloader_module_default()).bg
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                className: (logoPreloader_module_default()).logo,
                src: "/MAIN_ENVI.svg",
                alt: "SVG Image",
                width: "400",
                height: "400"
            })
        ]
    });
}

// EXTERNAL MODULE: ./app/components/MainPageBlocks/mainPageBlocks.module.css
var mainPageBlocks_module = __webpack_require__(913);
var mainPageBlocks_module_default = /*#__PURE__*/__webpack_require__.n(mainPageBlocks_module);
;// CONCATENATED MODULE: ./app/components/MainPageBlocks/MainPageBlocks.tsx


function MainPageBlocks() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (mainPageBlocks_module_default()).blocksContainer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (mainPageBlocks_module_default()).sectionOne,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (mainPageBlocks_module_default()).ecoRandom
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (mainPageBlocks_module_default()).ecology
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (mainPageBlocks_module_default()).sectionTwo,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (mainPageBlocks_module_default()).sectionTwo_subBlock,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (mainPageBlocks_module_default()).earth
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (mainPageBlocks_module_default()).ecoShadow
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (mainPageBlocks_module_default()).sectionTwo__engineerSaveNature,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (mainPageBlocks_module_default()).engineer
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (mainPageBlocks_module_default()).saveNature,
                                        children: "СОХРАНЯЯ ПРИРОДУ ДЛЯ БУДУЩИХ ПОКОЛЕНИЙ"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (mainPageBlocks_module_default()).ppa
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (mainPageBlocks_module_default()).sectionThree,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (mainPageBlocks_module_default()).catPlasmaContainer,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (mainPageBlocks_module_default()).cat
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (mainPageBlocks_module_default()).plasma
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (mainPageBlocks_module_default()).calcFormulaContainer,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (mainPageBlocks_module_default()).calc
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (mainPageBlocks_module_default()).formula
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






function Home() {
    const [isMenuActive, setIsMenuActive] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: (page_module_default()).main,
        onClick: ()=>setIsMenuActive(false),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(LogoPreloader, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: (page_module_default()).content,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(BurgerBtn, {
                        activateMenuFunc: setIsMenuActive
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(BurgerContent, {
                        isActive: isMenuActive,
                        activateMenuFunc: setIsMenuActive
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(MainPageBlocks, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 2897:
/***/ ((module) => {

// Exports
module.exports = {
	"btn": "burger-menu_btn__OAik0",
	"line": "burger-menu_line__PDmfb",
	"menuContent": "burger-menu_menuContent__V2rCZ",
	"menuActive": "burger-menu_menuActive__EOQwi",
	"closeBtn": "burger-menu_closeBtn__3ptdo",
	"closeBtnWrap": "burger-menu_closeBtnWrap__QCk4_",
	"menuList": "burger-menu_menuList__T53pd",
	"menuListTitle": "burger-menu_menuListTitle__IAvjV",
	"menuListSubTitle": "burger-menu_menuListSubTitle__SPnFQ",
	"blur": "burger-menu_blur__HBf8D",
	"none": "burger-menu_none__p1FU_"
};


/***/ }),

/***/ 5965:
/***/ ((module) => {

// Exports
module.exports = {
	"preloader": "logoPreloader_preloader__pnRjX",
	"logo": "logoPreloader_logo__Axdy_",
	"bg": "logoPreloader_bg__LZ8g5",
	"logoToCorner": "logoPreloader_logoToCorner__mAgZb",
	"backgroundToBlack": "logoPreloader_backgroundToBlack__1szrK"
};


/***/ }),

/***/ 913:
/***/ ((module) => {

// Exports
module.exports = {
	"blocksContainer": "mainPageBlocks_blocksContainer__sgDf6",
	"sectionOne": "mainPageBlocks_sectionOne__TdjuC",
	"ecoRandom": "mainPageBlocks_ecoRandom__Yz9QR",
	"ecology": "mainPageBlocks_ecology__k1VT2",
	"sectionTwo": "mainPageBlocks_sectionTwo__THWGo",
	"sectionTwo_subBlock": "mainPageBlocks_sectionTwo_subBlock__wlGP4",
	"earth": "mainPageBlocks_earth__bTmAp",
	"ecoShadow": "mainPageBlocks_ecoShadow__UCeR4",
	"sectionTwo__engineerSaveNature": "mainPageBlocks_sectionTwo__engineerSaveNature__7yTN4",
	"engineer": "mainPageBlocks_engineer__NGfUa",
	"saveNature": "mainPageBlocks_saveNature__87Lsz",
	"ppa": "mainPageBlocks_ppa__SbJs9",
	"sectionThree": "mainPageBlocks_sectionThree__edRIB",
	"catPlasmaContainer": "mainPageBlocks_catPlasmaContainer__8aAOv",
	"cat": "mainPageBlocks_cat__u93l_",
	"plasma": "mainPageBlocks_plasma__sWKvV",
	"calcFormulaContainer": "mainPageBlocks_calcFormulaContainer__ziFhI",
	"calc": "mainPageBlocks_calc__Ta0qI",
	"formula": "mainPageBlocks_formula__PRq9r"
};


/***/ }),

/***/ 1184:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "page_main__nw1Wk",
	"notVisible": "page_notVisible__eMoVl",
	"content": "page_content___38fW"
};


/***/ }),

/***/ 2838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/egor/Desktop/WEB/envipro/envipro/app/page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [918,63], () => (__webpack_exec__(6688)));
module.exports = __webpack_exports__;

})();